# SNAKE 2

## How to run.
1. Install python 3.9 and pygame.
2.     python Snake2.py
